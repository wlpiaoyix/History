//
//  SSY_Contants.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-1-9.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSY_Contants : NSObject
-(bool) ifWouldSynchroze;
-(bool) synchrozeLocationAllData;
-(NSString*) synchrozeWebAllData;
@end
