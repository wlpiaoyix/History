//
//  CloubContentsController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-5.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import "BaseViewController.h"

@interface CloubContentsController : BaseViewController<NSURLConnectionDelegate,UIAlertViewDelegate>
+(id) getNewleInstance;

@end
