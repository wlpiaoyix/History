//
//  RegistController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-10.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface RegistController : BaseViewController
+(id) getNewInstance;
@end
