//
//  ET_PhoneNumCell.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-1-26.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ET_PhoneNumCell : UITableViewCell
-(void) setData:(NSString*) name Address:(NSString*) address ImageUrl:(NSString*) imageUrl;
@end
