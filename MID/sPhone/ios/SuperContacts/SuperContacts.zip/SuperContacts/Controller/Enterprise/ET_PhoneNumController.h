//
//  ET_PhoneNumController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-1-23.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface ET_PhoneNumController : BaseViewController
+(id) getNewInstance;

@end
