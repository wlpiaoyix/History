//
//  UIRecordPhoneHeadView.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-28.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIRecordPhoneHeadView : UIView
+(id) getNewInstance;
-(void) setHeadText:(NSString*) title;

@end
