//
//  MADE_COMMON.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-28.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MADE_COMMON : NSObject
+(NSString*) parsetAddTag:(NSString*) tag Url:(NSString*) url;
+(UIImage*) pasetImage110:(UIImage*) image;
+(void) pasetImageAddWrite110ak640:(NSString*) url;
+(void) deleteImage110ak640:(NSString*) url;
@end
