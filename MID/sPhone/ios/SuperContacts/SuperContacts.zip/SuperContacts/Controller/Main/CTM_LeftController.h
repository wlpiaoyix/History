//
//  CTM_LeftController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-1-8.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CTM_LeftController : UIViewController
+(id) getSingleInstance;
@end
