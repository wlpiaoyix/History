//
//  SysSetAboutUsController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-3-10.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SysSetAboutUsController : UIViewController
+(id) getNewInstance;
@end
