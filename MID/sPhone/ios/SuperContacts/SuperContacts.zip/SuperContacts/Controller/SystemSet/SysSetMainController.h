//
//  SysSetMainController.h
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-1.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface SysSetMainController : BaseViewController<UIAlertViewDelegate>
+(id) getSingleInstance;
@end
