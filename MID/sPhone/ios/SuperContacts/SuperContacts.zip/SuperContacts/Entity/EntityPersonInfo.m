//
//  ModelPersonInfo.m
//  SuperContacts
//
//  Created by wlpiaoyi on 14-2-4.
//  Copyright (c) 2014年 wlpiaoyi. All rights reserved.
//

#import "EntityPersonInfo.h"

@implementation EntityPersonInfo
@end
