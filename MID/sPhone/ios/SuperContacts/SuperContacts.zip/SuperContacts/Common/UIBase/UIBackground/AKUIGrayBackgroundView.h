//
//  AKUIGrayBackgroundView.h
//  AKSL-189-Msp
//
//  Created by AKSL-td on 13-11-10.
//  Copyright (c) 2013年 AKSL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKUIGrayBackgroundView : UIView

@end
